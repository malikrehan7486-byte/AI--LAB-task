"""Shared record retriever: TF-IDF baseline or real sentence embeddings."""
import numpy as np
from lab6_pipeline import TfidfIndex
class Retriever:
    def __init__(self,records,backend='tfidf'):
        if not records or any(not r['text'].strip() for r in records): raise ValueError('Provide nonempty records')
        self.records=records; self.backend=backend; texts=[r['text'] for r in records]
        if backend=='tfidf': self.index=TfidfIndex().fit(texts)
        elif backend=='embedding':
            from sentence_transformers import SentenceTransformer
            self.model=SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2',device='cpu')
            self._check(texts); self.matrix=self.model.encode(texts,normalize_embeddings=True)
        else: raise ValueError('Use tfidf or embedding')
    def _check(self,texts):
        for t in texts:
            n=len(self.model.tokenizer(t,truncation=False)['input_ids'])
            if n>self.model.max_seq_length: raise ValueError(f'Input has {n} tokens; model limit {self.model.max_seq_length}')
    def search(self,query,k=3,filters=None):
        if not query.strip() or k<=0:return []
        if self.backend=='tfidf': scores=self.index.scores([query])[0]
        else:
            self._check([query]); q=self.model.encode([query],normalize_embeddings=True)[0]; scores=(self.matrix@q).tolist()
        allowed=[i for i,r in enumerate(self.records) if all(r.get(key)==value for key,value in (filters or {}).items())]
        ids=sorted(allowed,key=lambda i:(-float(scores[i]),i))[:k]
        return [(self.records[i],float(scores[i])) for i in ids]

def show_hits(hits):
    if not hits: print('No matching records.')
    for record,score in hits: print(record['id'],f'score={score:.3f}',record['text'])
