from task1_tokens import SAMPLES
