from lab6_pipeline import TfidfIndex
records=[{'id':'assessment:late','source':'handbook.txt','text':'Late submission is normally penalized. Students with illness may request an extension with medical evidence before the deadline.'},{'id':'assessment:format','source':'handbook.txt','text':'Submit the assignment as a PDF through the learning portal.'}]
q='illness medical evidence late submission'; scores=TfidfIndex().fit([r['text'] for r in records]).scores([q])[0]
for i in sorted(range(len(scores)),key=lambda i:(-scores[i],i))[:1]: print(records[i]['id'],f'{scores[i]:.3f}',records[i]['source'],records[i]['text'])
