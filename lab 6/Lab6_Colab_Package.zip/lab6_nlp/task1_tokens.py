"""Task 1: token comparison and conservative FAQ retrieval."""
import re
from lab6_pipeline import SAMPLES,TfidfIndex
for text in SAMPLES:
    ws=text.split(); words=re.findall(r"\b\w+\b",text,flags=re.UNICODE)
    print(repr(text),'whitespace',ws,len(ws),'word-like',words,len(words))
FAQ=[
 {'question':'How do I reset my password?','answer':'Use the recovery link on the login page.','source':'it_help.txt'},
 {'question':'Where do I submit my assignment?','answer':'Use the assignment upload page in the learning portal.','source':'assessment.txt'},
 {'question':'Can illness justify a late submission?','answer':'Request an extension with medical evidence before the deadline.','source':'handbook_current.txt'},
 {'question':'What should I do about a damaged parcel?','answer':'Report it within 48 hours and attach photographs.','source':'returns_guide.txt'},
 {'question':'Can a processing fee be reviewed?','answer':'A documented processing error can be reviewed by billing.','source':'fees_guide.txt'}]
engine=TfidfIndex().fit([r['question']+' '+r['answer'] for r in FAQ])
def reply(q):
    if not q.strip(): return 'Please enter a question.'
    for r in FAQ:
        if q.strip().casefold()==r['question'].casefold(): return r['answer']+' [source: '+r['source']+']'
    scores=engine.scores([q])[0]; order=sorted(range(len(scores)),key=lambda i:(-scores[i],i))
    if not scores or max(scores)==0: return 'No matching FAQ. Please contact the help desk.'
    return 'Possible matches; choose or rephrase:\n'+'\n'.join(FAQ[i]['question']+f' ({scores[i]:.3f})' for i in order[:3] if scores[i]>0)
for q in ['How do I reset my password?','password recovery','','volcano geology']:
 print('\nYou:',repr(q),'\nBot:',reply(q))
