from lab6_pipeline import TfidfIndex
records=[{'id':'remote:staff','audience':'employee','text':'Employees may request remote work with manager approval.'},{'id':'remote:contractor','audience':'contractor','text':'Contractors may work remotely only when the signed contract explicitly permits remote work.'}]
filtered=[r for r in records if r['audience']=='contractor']; q='remote work'; scores=TfidfIndex().fit([r['text'] for r in filtered]).scores([q])[0]
for i in sorted(range(len(scores)),key=lambda i:(-scores[i],i))[:1]: print(filtered[i]['id'],f'{scores[i]:.3f}',filtered[i]['text'])
