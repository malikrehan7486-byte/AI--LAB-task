# Lab 6 NLP Pipeline

This folder contains a runnable, Colab-ready Lab 6 pipeline using synthetic teaching text only. The script compares whitespace and Unicode word-like tokenization, FAQ exact answers and suggestions, three chunking strategies, TF-IDF, and (when the encoder can be loaded) real MiniLM sentence embeddings. It writes `corpus.json`, `queries.json`, and `retrieval_log.csv`.

## Run locally

Python 3.10 or newer:

```bash
python -m pip install -r requirements.txt
python lab6_pipeline.py
```

The MiniLM encoder loads on CPU and may download model files. If it is unavailable, the script records that the embedding portion was not run; it does not invent embedding values. In this environment, `Lab6_Local_Output.txt` and `retrieval_log.csv` contain the completed TF-IDF run only. Run the notebook in Colab to add actual embedding results.

## Run in Google Colab

Open `Lab6_Colab.ipynb` in Colab and choose Runtime > Run all. The first cell installs `sentence-transformers`; the later cell loads `sentence-transformers/all-MiniLM-L6-v2` on CPU and writes a Colab output text file and CSV in the runtime. Download those generated files before the temporary Colab runtime ends.

## Files

- `lab6_pipeline.py` implements the complete three-task pipeline and creates synthetic corpus/query data.
- `task1_tokens.py`, `task2_chunks.py`, `task3_retrieval.py` provide task-specific entry points.
- `document_chatbot.py` displays candidates with source offsets and requires a selection before showing a passage.
- `scenario1_handbook.py` through `scenario5_equipment.py` are small guided examples.
- `corpus.json`, `queries.json`, `retrieval_log.csv`, `Lab6_Local_Output.txt` are reproducible inputs and local outputs.
- `Lab6_Colab.ipynb` embeds the pipeline and is the file to upload to Colab.

All policies and records are synthetic. Retrieval scores are not probabilities or proof that a passage is current, complete, or correct. The TF-IDF implementation uses smoothed IDF and L2 normalization; the embedding path uses the pretrained model rather than hand-invented vectors.
