"""Interactive evidence display. Candidates are never asserted as answers."""
import json
from pathlib import Path
from lab6_pipeline import make_chunks
from lab6_search import Retriever
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    docs=json.loads((ROOT/'corpus.json').read_text(encoding='utf-8'))
    config_path=ROOT/'selected_config.json'
    config=json.loads(config_path.read_text(encoding='utf-8')) if config_path.exists() else {'strategy':'sentence','backend':'tfidf'}
    chunks=make_chunks(docs,config['strategy'])
    engine=Retriever(chunks,config['backend'])
    print('Using development-selected configuration:',config['strategy'],config['backend'])
    print('Evidence assistant. Type exit to stop.')
    while True:
        try: query=input('Question: ')
        except (EOFError,KeyboardInterrupt): break
        if query.strip().lower()=='exit': break
        if not query.strip(): print('Please enter a question.'); continue
        hits=engine.search(query,k=3)
        if not hits or (config['backend']=='tfidf' and hits[0][1]==0): print('No candidate evidence; rephrase or contact a human.'); continue
        for rank,(c,score) in enumerate(hits,1): print(rank,c['id'],f'{score:.3f}',c['source'],f"chars {c['start']}-{c['end']}")
        choice=input('Choose 1-3 to inspect; Enter if none apply: ')
        if not choice.isdigit() or not 1<=int(choice)<=len(hits): print('No passage selected. Rephrase or contact a human.'); continue
        c=hits[int(choice)-1][0]
        print('Candidate evidence:',c['text']); print('Source:',c['source'],'characters',c['start'],c['end'])
