from lab6_pipeline import TfidfIndex
records=[{'id':'printer:blank','device':'printer','text':'For blank printer pages: 1. Check ink level. 2. Run the printer cleaning utility. 3. Print a test page. Follow the device manual.'},{'id':'scanner:blank','device':'scanner','text':'For a blank scanner image, check document placement and select the correct scanning source.'}]
filtered=[r for r in records if r['device']=='printer']; q='blank pages'; scores=TfidfIndex().fit([r['text'] for r in filtered]).scores([q])[0]
for i in sorted(range(len(scores)),key=lambda i:(-scores[i],i))[:1]: print(filtered[i]['id'],f'{scores[i]:.3f}',filtered[i]['text'])
