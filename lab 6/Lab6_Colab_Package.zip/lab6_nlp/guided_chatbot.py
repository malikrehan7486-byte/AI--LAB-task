from task1_tokens import FAQ,reply,engine
print('FAQ assistant. Exact questions return a sourced answer; other queries return suggestions.')
for query in ['How do I reset my password?','password recovery','','volcano geology']:
 print('You:',repr(query)); print('Bot:',reply(query))
