"""Lab 6 runnable NLP retrieval pipeline; all records and rules are synthetic."""
import csv, json, math, re, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SAMPLES=["AI, search!", "I can't log in.", "help@example.com", "CS4944 version 2.1", "", "کیا میں آج دیر سے جمع کرا سکتا ہوں؟"]

# Six synthetic teaching documents. The current and archived assessment notes deliberately conflict.
DOCS={
"handbook_current": """Assessment submissions should be uploaded through the learning portal before the deadline listed in the course outline. Upload assignments through the learning portal as PDF files. The portal displays a receipt after a successful upload, and students should save that receipt. Late submission is normally penalized according to the course outline. Illness extensions require medical evidence before the deadline. A student who cannot provide evidence before the deadline should contact the course coordinator promptly and explain the situation. The coordinator records the request and the date it was received. A file that is still uploading is not treated as submitted until the portal confirms receipt. If a portal outage is documented, students should keep a screenshot and contact support. Instructors may clarify a course-specific deadline, but a verbal estimate should be checked against the published outline. Students should not send passwords or medical records through public discussion boards. This synthetic handbook excerpt is for retrieval practice only and is not a real university policy. Preserve the complete exception when quoting the general late rule. Keep the document title and revision date with any excerpt. If two sources disagree, check the current approved document and ask the responsible office before relying on a rule. The retrieval prototype does not decide whether an extension is approved. It only returns candidate evidence for a person to review.""",
"handbook_archive": """ARCHIVE COPY - prior-year draft, not current policy. An older assessment draft stated that submissions after the deadline were not accepted, including when a student reported illness. This sentence conflicts with the current synthetic handbook, which permits a documented illness-extension request before the deadline. The archived draft is retained only to test retrieval when two passages use similar words. It must not be treated as the active rule. The file label and revision date are important metadata. A search system may rank this passage highly because it repeats terms such as late submission, deadline, illness, evidence, and extension. A reader should inspect the source date and current status before drawing a conclusion. When the archive is retrieved, compare it with handbook_current and prefer the current version for this exercise. Do not combine the two versions into one answer. This synthetic archive is not a real university policy and creates no student rights or obligations. A prototype that retrieves the wrong version should show its source clearly and allow a human to reject it. Evaluation should count an archived passage as irrelevant when the query is labeled for the current handbook. The conflict demonstrates why metadata and source review matter as much as similarity scores.""",
"it_help": """Campus IT help describes account recovery and safe handling of credentials. Reset a forgotten password using the recovery link. The link is sent to the verified recovery email address and expires after a short period. If recovery email is unavailable, contact the campus help desk after verifying your identity. Staff will never ask a student to post a password or one-time code in a ticket. Recovery codes should be stored privately and not copied into shared documents. If a sign-in alert was unexpected, change the password from the official portal and report the alert to IT. Do not follow account links from an unsolicited message. The help desk may ask for an account name but should not request the secret itself. These instructions are synthetic and do not connect to any actual account. A source excerpt should preserve the warning next to the recovery step. Search results are candidates, not proof that a message is authentic. For a locked account, use the official support channel listed in the current IT guide. If an instruction seems inconsistent, stop and ask IT to confirm before entering credentials. Keep version labels when copying steps into a ticket.""",
"returns_guide": """Synthetic returns guide for retrieval exercises. Inspect the parcel and packaging promptly after delivery. Damaged parcels must be reported within 48 hours with photographs of the item and packaging. If the reporting window is close to expiring, the customer should contact support immediately, preserve the packaging, retain clear photographs, record the delivery date, and ask for a case number; however, these steps do not extend the stated reporting period unless the responsible support office confirms an exception in writing. Keep the order number available when contacting the support desk, but do not post it in a public forum. A photograph should show the damage clearly without including unrelated personal information. The support team will provide a case number and explain whether the item should be kept for inspection. Do not discard the packaging until the case is reviewed. A change-of-mind return follows a different process and does not use the damage-report deadline. Items from another region may have a different reporting window, so the region field should be checked. The examples in this document are fictional and are not a merchant promise. Keep the deadline and evidence requirement together when retrieving the damage procedure. If the guide does not identify a product or region, ask support rather than guessing. A search result does not authorize a refund. The final resolution depends on a human review of the documented case.""",
"fees_guide": """Synthetic billing guide for retrieval experiments. The published processing fee applies to requests submitted after the stated billing date. The billing office can review an exception when the fee resulted from a documented processing error. The published fee cannot be waived; a documented processing error can be reviewed by the billing office. Include the transaction date and a short explanation when opening a private support ticket. Do not send bank details or full payment credentials in ordinary email. A review is not a promise that a refund will be granted. Staff should compare the receipt with the current schedule and explain any discrepancy. If the fee appears twice, provide the two reference dates through the secure portal. This text is fictional teaching material, not an actual fee rule. Preserve the exception next to the general fee condition when citing the source. An answer that mentions only the first sentence could be misleading. If the case is unclear, refer it to the billing office for a decision. The retrieval exercise only checks whether evidence is found; it does not determine a student's balance or eligibility.""",
"workplace_guide": """Synthetic workplace guide used to test related passages. Employees may request remote work with manager approval, subject to their role and current team schedule. Contractors may work remotely only when the signed contract explicitly permits remote work. A general employee arrangement does not automatically apply to a contractor. The contract owner should check the signed version and any later amendment before confirming eligibility. Do not share confidential contract terms in a public channel. If the clause is missing or unclear, ask the contract owner for review. A search result should preserve the audience restriction and the signed-contract condition. The guide is fictional and is not employment advice or an actual company policy. It is included because a broad query about remote work may retrieve the employee rule even when the question concerns a contractor. Metadata such as audience can narrow candidates, but it is not an access-control mechanism. The final interpretation belongs to an authorized human reviewer. Keep the document version and source path with any excerpt. Do not infer permission from a high similarity score alone."""
}
SOURCES={k:f"synthetic/{k}.txt" for k in DOCS}
QUERIES=[
 {"query":"What proof is needed for an illness extension?","doc":"handbook_current","evidence":"Illness extensions require medical evidence before the deadline.","split":"dev"},
 {"query":"How can I reset a forgotten account password?","doc":"it_help","evidence":"Reset a forgotten password using the recovery link.","split":"dev"},
 {"query":"What do I send for a damaged parcel report?","doc":"returns_guide","evidence":"Damaged parcels must be reported within 48 hours with photographs of the item and packaging.","split":"dev"},
 {"query":"When can the published fee be reviewed?","doc":"fees_guide","evidence":"The published fee cannot be waived; a documented processing error can be reviewed by the billing office.","split":"dev"},
 {"query":"Where should coursework be uploaded and in what format?","doc":"handbook_current","evidence":"Upload assignments through the learning portal as PDF files.","split":"test"},
 {"query":"What if my recovery email is unavailable?","doc":"it_help","evidence":"If recovery email is unavailable, contact the campus help desk after verifying your identity.","split":"test"},
 {"query":"How soon should I report damage and what proof is needed?","doc":"returns_guide","evidence":"Damaged parcels must be reported within 48 hours with photographs of the item and packaging.","split":"test"},
 {"query":"Can a contractor work remotely?","doc":"workplace_guide","evidence":"Contractors may work remotely only when the signed contract explicitly permits remote work.","split":"test"},
 {"query":"What are tomorrow's flight prices?","doc":None,"evidence":None,"split":"test"},
 {"query":"Who won the football final?","doc":None,"evidence":None,"split":"test"}
]

def word_spans(text): return [(m.start(),m.end()) for m in re.finditer(r"\S+",text)]
def windows(text,size=40,overlap=10,offset=0):
    if size<=0 or not 0<=overlap<size: raise ValueError("Require size > 0 and 0 <= overlap < size")
    spans=word_spans(text); out=[]
    for i in range(0,len(spans),size-overlap):
        j=min(i+size,len(spans)); out.append((offset+spans[i][0],offset+spans[j-1][1]))
        if j==len(spans): break
    return out

def sentence_chunks(text,size=40,offset=0):
    if size<=0: raise ValueError("size must be positive")
    cuts=[0]+[m.end() for m in re.finditer(r"[.!?]\s+",text)]+[len(text)]
    out=[]; pending=None; count=0
    for a,b in zip(cuts,cuts[1:]):
        n=len(text[a:b].split())
        if not n: continue
        if n>size:
            if pending is not None: out.append(pending); pending=None; count=0
            out.extend(windows(text[a:b],size,0,offset+a))
        elif pending is not None and count+n<=size:
            pending=(pending[0],offset+b); count+=n
        else:
            if pending is not None: out.append(pending)
            pending=(offset+a,offset+b); count=n
    if pending is not None: out.append(pending)
    return out

def make_chunks(docs,strategy,doc_ids=None):
    ids=list(doc_ids or docs.keys()); out=[]
    for doc_id in ids:
        text=docs[doc_id]
        spans=sentence_chunks(text) if strategy=="sentence" else windows(text,40,int(strategy))
        for i,(a,b) in enumerate(spans):
            out.append({"id":f"{doc_id}:{i}","doc":doc_id,"source":SOURCES[doc_id],"start":a,"end":b,"text":text[a:b]})
    return out

def tokens(text): return re.findall(r"(?u)\b\w\w+\b",text.lower())
class TfidfIndex:
    """Small standard smoothed TF-IDF baseline with L2 normalization."""
    def fit(self,texts):
        self.n=len(texts); docs=[tokens(t) for t in texts]; df={}
        for ts in docs:
            for term in set(ts): df[term]=df.get(term,0)+1
        self.idf={term:1+math.log((1+self.n)/(1+n)) for term,n in df.items()}
        self.vectors=[self._vector(ts) for ts in docs]
        return self
    def _vector(self,ts):
        counts={}
        for t in ts:
            if t in self.idf: counts[t]=counts.get(t,0)+1
        v={t:n*self.idf[t] for t,n in counts.items()}; norm=math.sqrt(sum(x*x for x in v.values()))
        return {t:x/norm for t,x in v.items()} if norm else {}
    def scores(self,queries):
        rows=[]
        for q in queries:
            v=self._vector(tokens(q)); rows.append([sum(x*v.get(t,0.0) for t,x in row.items()) for row in self.vectors])
        return rows

def exact_metrics(rankings,items,chunks):
    hits=[]; rr=[]
    for ids,q in zip(rankings,items):
        if q["doc"] is None: continue
        ranks=[rank for rank,i in enumerate(ids[:3],1) if chunks[i]["doc"]==q["doc"] and q["evidence"] in chunks[i]["text"]]
        hits.append(bool(ranks)); rr.append(1/ranks[0] if ranks else 0.0)
    return (sum(hits)/len(hits),sum(rr)/len(rr)) if hits else (None,None)

def run():
    (ROOT/'corpus.json').write_text(json.dumps(DOCS,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'queries.json').write_text(json.dumps(QUERIES,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DOCUMENT WORD COUNTS')
    for k,t in DOCS.items(): print(k,len(t.split()),SOURCES[k])
    print('\nTASK 1 TOKENIZATION')
    for text in SAMPLES:
        ws=text.split(); wl=re.findall(r"\b\w+\b",text,flags=re.UNICODE)
        print(repr(text),'whitespace=',ws,'count=',len(ws),'word_like=',wl,'count=',len(wl))
    print('Risk: lowercasing or punctuation stripping can damage negation, case-sensitive IDs, emails and source fidelity.')
    print('\nTASK 1 FAQ TRANSCRIPT (TF-IDF baseline)')
    faqs=[{"id":"faq:password","question":"How do I reset my password?","answer":"Use the recovery link on the login page.","source":"it_help.txt"},{"id":"faq:submit","question":"Where do I submit my assignment?","answer":"Use the assignment upload page in the learning portal.","source":"assessment.txt"},{"id":"faq:late","question":"Can illness justify a late submission?","answer":"Request an extension with medical evidence before the deadline.","source":"handbook_current.txt"},{"id":"faq:damage","question":"What should I do about a damaged parcel?","answer":"Report it within 48 hours and attach photographs.","source":"returns_guide.txt"},{"id":"faq:fee","question":"Can a processing fee be reviewed?","answer":"A documented processing error can be reviewed by billing.","source":"fees_guide.txt"}]
    fi=TfidfIndex().fit([x['question']+' '+x['answer'] for x in faqs])
    def faq_reply(q):
        if not q.strip(): return 'Please enter a question.'
        for r in faqs:
            if q.strip().casefold()==r['question'].casefold(): return r['answer']+' [source: '+r['source']+']'
        scores=fi.scores([q])[0]; ranks=sorted(range(len(scores)),key=lambda i:(-scores[i],i))
        if not scores or max(scores)==0: return 'No matching FAQ. Please contact the help desk.'
        return 'Possible matches; choose or rephrase your question:\n'+'\n'.join(f"{faqs[i]['question']} (similarity {scores[i]:.3f})" for i in ranks[:3] if scores[i]>0)
    for q in ['How do I reset my password?','password recovery','', 'volcano geology']:
        print('You:',repr(q)); print('Bot:',faq_reply(q))
    print('Nonexact questions return candidates for confirmation; similarity is not proof of answerability.')
    print('\nTASK 2 CHUNKING')
    subset={k:DOCS[k] for k in ['handbook_current','it_help','returns_guide']}
    rule_evidence=[QUERIES[0]['evidence'],QUERIES[1]['evidence'],QUERIES[2]['evidence']]
    source_words=sum(len(t.split()) for t in subset.values())
    for strategy in ['0','10','sentence']:
        chunks=make_chunks(subset,strategy); sizes=[len(c['text'].split()) for c in chunks]
        repeated=sum(sizes)-source_words
        retained=[sum(1 for c in chunks if c['doc']==q['doc'] and q['evidence'] in c['text']) for q in QUERIES[:3]]
        assert all(c['text']==subset[c['doc']][c['start']:c['end']] for c in chunks)
        print(strategy,'chunks=',len(chunks),'min/max words=',(min(sizes),max(sizes)),'repeated word units=',repeated,'rule evidence chunk counts=',retained)
    assert windows('')==[] and len(windows('short text'))==1
    try: windows('a b',2,2)
    except ValueError: print('invalid overlap test: PASS')
    long=' '.join(['word']*95)+'.'; assert max(len(long[a:b].split()) for a,b in sentence_chunks(long))<=40
    print('empty text, short text, invalid overlap, 95-word sentence fallback: PASS')
    abbrev='Dr. ' + ' '.join(['The policy applies to this case']*11) + '.'
    print('abbreviation example chunks:',[abbrev[a:b] for a,b in sentence_chunks(abbrev,40)])
    print('\nTASK 2 PARAPHRASE SUGGESTIONS (TF-IDF)')
    c=make_chunks(subset,'sentence'); ix=TfidfIndex().fit([r['text'] for r in c])
    for q in ['I was sick; can I hand it in tomorrow?','My package arrived broken','I forgot my account login']:
        sc=ix.scores([q])[0]; ranked=sorted(range(len(sc)),key=lambda i:(-sc[i],i))[:3]
        print('query:',q)
        for i in ranked: print(c[i]['id'],f'{sc[i]:.3f}',c[i]['text'][:220])
    print('\nTASK 3 SIX-CONFIG EVALUATION')
    configs=[('windows_ov0','0'),('windows_ov10','10'),('sentence','sentence')]
    rows=[]; dev_scores=[]
    model=None; model_load=None
    try:
        from sentence_transformers import SentenceTransformer
        started=time.perf_counter(); model=SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2',device='cpu'); model_load=time.perf_counter()-started
        print('Embedding model load seconds:',round(model_load,3),'model: sentence-transformers/all-MiniLM-L6-v2')
    except Exception as e:
        print('Embedding backend NOT RUN in this environment:',type(e).__name__,str(e)[:180])
    if model is not None:
        print('MODEL SUBWORD TOKENIZER examples:')
        for sample in SAMPLES[:2]: print(repr(sample),model.tokenizer.tokenize(sample),len(model.tokenizer(sample,truncation=False)['input_ids']))
        print('TASK 2 PARAPHRASE SUGGESTIONS (real sentence embeddings)')
        mini=make_chunks(subset,'sentence'); mini_text=[c['text'] for c in mini]
        para_queries=['I was sick; can I hand it in tomorrow?','My package arrived broken','I forgot my account login']
        lens=[len(model.tokenizer(t,truncation=False)['input_ids']) for t in mini_text+para_queries]
        if max(lens)>model.max_seq_length: raise ValueError('Task 2 text exceeds encoder limit')
        Cmini=model.encode(mini_text,normalize_embeddings=True); Qmini=model.encode(para_queries,normalize_embeddings=True)
        for q,Qrow in zip(para_queries,Qmini):
            sc=(Qrow@Cmini.T).tolist(); order=sorted(range(len(sc)),key=lambda i:(-sc[i],i))[:3]
            print('query:',q)
            for i in order: print(mini[i]['id'],f'{sc[i]:.3f}',mini[i]['source'],mini[i]['start'],mini[i]['end'],mini[i]['text'][:220])
    else:
        print('TASK 2 embedding suggestions pending: run this notebook in Colab to load the pretrained encoder.')
    for strat,strategy in configs:
        chunks=make_chunks(DOCS,strategy); texts=[x['text'] for x in chunks]; qtexts=[q['query'] for q in QUERIES]
        orig_word_count=sum(len(t.split()) for t in DOCS.values()); dup=sum(len(t.split()) for t in texts)-orig_word_count
        # TF-IDF baseline
        t0=time.perf_counter(); tf=TfidfIndex().fit(texts); all_scores=tf.scores(qtexts); enc=time.perf_counter()-t0
        t1=time.perf_counter(); tf_rankings=[sorted(range(len(row)),key=lambda i:(-row[i],i))[:3] for row in all_scores]; search=time.perf_counter()-t1
        for split in ['dev','test']:
            ixq=[i for i,q in enumerate(QUERIES) if q['split']==split and q['doc'] is not None]
            met=exact_metrics([tf_rankings[i] for i in ixq],[QUERIES[i] for i in ixq],chunks)
            print(strat,'tfidf',split,'Hit@3/MRR@3=',tuple(round(x,3) for x in met),'chunks=',len(chunks),'encode/search sec=',round(enc,4),round(search,4),'duplicate words=',dup)
            if split=='dev': dev_scores.append((met[0],met[1],strat,'tfidf',strategy))
        for qi,q in enumerate(QUERIES):
            for rank,ci in enumerate(tf_rankings[qi],1):
                ch=chunks[ci]; rows.append({'strategy':strat,'backend':'tfidf','query':q['query'],'split':q['split'],'answerable':q['doc'] is not None,'rank':rank,'score':all_scores[qi][ci],'chunk_id':ch['id'],'doc':ch['doc'],'source':ch['source'],'start':ch['start'],'end':ch['end'],'text':ch['text']})
        if model is not None:
            all_text=texts+qtexts; lens=[len(model.tokenizer(x,truncation=False)['input_ids']) for x in all_text]
            print(strat,'token length max=',max(lens),'model limit=',model.max_seq_length)
            if max(lens)>model.max_seq_length: raise ValueError('Model token limit exceeded; rechunk before encoding')
            t0=time.perf_counter(); C=model.encode(texts,normalize_embeddings=True); Q=model.encode(qtexts,normalize_embeddings=True); enc=time.perf_counter()-t0
            t1=time.perf_counter(); scores=(Q@C.T).tolist(); emb_rankings=[sorted(range(len(row)),key=lambda i:(-row[i],i))[:3] for row in scores]; search=time.perf_counter()-t1
            for split in ['dev','test']:
                ixq=[i for i,q in enumerate(QUERIES) if q['split']==split and q['doc'] is not None]
                met=exact_metrics([emb_rankings[i] for i in ixq],[QUERIES[i] for i in ixq],chunks)
                print(strat,'embedding',split,'Hit@3/MRR@3=',tuple(round(x,3) for x in met),'chunks=',len(chunks),'encode/search sec=',round(enc,4),round(search,4),'duplicate words=',dup)
                if split=='dev': dev_scores.append((met[0],met[1],strat,'embedding',strategy))
            for qi,q in enumerate(QUERIES):
                for rank,ci in enumerate(emb_rankings[qi],1):
                    ch=chunks[ci]; rows.append({'strategy':strat,'backend':'embedding','query':q['query'],'split':q['split'],'answerable':q['doc'] is not None,'rank':rank,'score':scores[qi][ci],'chunk_id':ch['id'],'doc':ch['doc'],'source':ch['source'],'start':ch['start'],'end':ch['end'],'text':ch['text']})
            print('Top-three previews for',strat,'embedding:')
            for qi,q in enumerate(QUERIES):
                print('QUERY',q['split'],q['query'])
                for rank,ci in enumerate(emb_rankings[qi],1):
                    ch=chunks[ci]; print(rank,ch['id'],f"{scores[qi][ci]:.3f}",f"{ch['source']}:{ch['start']}-{ch['end']}",repr(ch['text'][:170]))
        print('Top-three previews for',strat,'TF-IDF:')
        for qi,q in enumerate(QUERIES):
            print('QUERY',q['split'],q['query'])
            for rank,ci in enumerate(tf_rankings[qi],1):
                ch=chunks[ci]; print(rank,ch['id'],f"{all_scores[qi][ci]:.3f}",f"{ch['source']}:{ch['start']}-{ch['end']}",repr(ch['text'][:170]))
    chosen=sorted(dev_scores,key=lambda x:(-x[0],-x[1],x[2],x[3]))[0]
    print('Development-only selected config:',chosen[2],chosen[3],'dev Hit/MRR',chosen[:2],'; chosen without test tuning.')
    (ROOT/'selected_config.json').write_text(json.dumps({'strategy':chosen[4],'backend':chosen[3],'dev_hit_at_3':chosen[0],'dev_mrr_at_3':chosen[1]},indent=2),encoding='utf-8')
    print('Selected configuration saved: selected_config.json')
    with (ROOT/'retrieval_log.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print('CSV saved: retrieval_log.csv rows=',len(rows))
    print('Unanswerable queries have top candidates but no relevance score; similarity alone cannot establish an answer.')
    print('FAILURE EXAMPLES (local TF-IDF, sentence chunks)')
    for qtext in ['What proof is needed for an illness extension?','How soon should I report damage and what proof is needed?','What are tomorrow\'s flight prices?']:
        qi=next(i for i,q in enumerate(QUERIES) if q['query']==qtext); q=QUERIES[qi]; chset=make_chunks(DOCS,'sentence'); ix=TfidfIndex().fit([c['text'] for c in chset]); sc=ix.scores([qtext])[0]; order=sorted(range(len(sc)),key=lambda i:(-sc[i],i))[:3]
        good=any(chset[i]['doc']==q['doc'] and q['doc'] is not None and q['evidence'] in chset[i]['text'] for i in order)
        print('query=',qtext,'answerable=',q['doc'] is not None,'full_evidence_in_top3=',good)
        for i in order[:1]: print('top result=',chset[i]['id'],f'{sc[i]:.3f}',repr(chset[i]['text']))
    print('Likely causes: short lexical overlap misses paraphrases; full evidence may rank below top 3; unanswerable text still overlaps common words. Improvements: use a validated embedding model, retain full exception context, inspect source/version metadata, and calibrate abstention separately on development data.')
    print('Document chatbot design: display top candidates and source spans, then require user selection before showing a passage; never auto-assert an answer.')

if __name__=='__main__': run()
