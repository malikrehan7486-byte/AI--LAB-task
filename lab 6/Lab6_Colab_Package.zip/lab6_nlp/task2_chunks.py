"""Task 2 chunking functions are shared with lab6_pipeline.py."""
from lab6_pipeline import windows,sentence_chunks,make_chunks,DOCS
if __name__=='__main__':
    for strategy in ['0','10','sentence']:
        chunks=make_chunks({k:DOCS[k] for k in ['handbook_current','it_help','returns_guide']},strategy)
        print(strategy,'count',len(chunks),'sample',chunks[0])
    assert windows('')==[] and windows('short text')
    try: windows('a b',2,2)
    except ValueError: print('invalid overlap rejected')
    long=' '.join(['word']*95)+'.'
    assert max(len(long[a:b].split()) for a,b in sentence_chunks(long))<=40
    print('empty, short, invalid-overlap, and long-sentence checks passed')
