from lab6_pipeline import TfidfIndex
records=[{'id':'returns:damage','region':'PK','text':'For a damaged parcel, contact support within 48 hours and attach photographs of the item and packaging.'},{'id':'returns:change','region':'PK','text':'For a change of mind, return unused items within 14 days.'},{'id':'returns:damage:other','region':'OTHER','text':'Damaged parcel reports in the other region have a 72 hour window.'}]
filtered=[r for r in records if r['region']=='PK']; q='damaged parcel photographs'; scores=TfidfIndex().fit([r['text'] for r in filtered]).scores([q])[0]
for i in sorted(range(len(scores)),key=lambda i:(-scores[i],i))[:1]: print(filtered[i]['id'],f'{scores[i]:.3f}',filtered[i]['text'])
