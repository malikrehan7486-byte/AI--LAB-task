"""Task 3: complete retrieval comparison. Produces retrieval_log.csv."""
from lab6_pipeline import run
if __name__=='__main__': run()
