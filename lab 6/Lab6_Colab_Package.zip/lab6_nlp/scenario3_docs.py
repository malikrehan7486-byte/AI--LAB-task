from lab6_pipeline import TfidfIndex
records=[{'id':'auth:v2','version':'v2','text':'Renew an expired API token with POST /v2/token/refresh. Send the refresh_token field; never print its value in logs.'},{'id':'auth:v1','version':'v1','text':'Renew an expired API token with POST /v1/auth/renew.'}]
filtered=[r for r in records if r['version']=='v2']; q='renew expired API token'; scores=TfidfIndex().fit([r['text'] for r in filtered]).scores([q])[0]
for i in sorted(range(len(scores)),key=lambda i:(-scores[i],i))[:1]: print(filtered[i]['id'],f'{scores[i]:.3f}',filtered[i]['text'])
