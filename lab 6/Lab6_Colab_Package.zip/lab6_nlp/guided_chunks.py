from task2_chunks import windows,sentence_chunks
text='Late work is penalized. Illness may qualify for an extension when medical evidence is provided. Ask the coordinator first.'
for name,spans in [('window-0',windows(text,40,0)),('window-10',windows(text,40,10)),('sentence',sentence_chunks(text,40))]:
 print(name,[(a,b,text[a:b]) for a,b in spans])
