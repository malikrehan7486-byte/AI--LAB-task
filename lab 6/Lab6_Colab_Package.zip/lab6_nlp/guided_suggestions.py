from task1_tokens import FAQ,engine
for query in ['assignment upload','forgot login']:
 print('Query:',query)
 scores=engine.scores([query])[0]
 for i in sorted(range(len(scores)),key=lambda i:(-scores[i],i))[:3]:
  if scores[i]>0: print(FAQ[i]['question'],f'({scores[i]:.3f})')
